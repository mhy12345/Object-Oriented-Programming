#include "member.h"

using std::cout;
using std::endl;
void Member::printInfo()const//输出成员信息
{
	cout<<"Name:"<<name<<endl;
	cout<<"Age:"<<age<<endl;
}
